#include <stdio.h>
#include <stdlib.h>
#include <time.h>

enum LogLevel { DEBUG, INFO, WARNING, ERROR };

typedef void (*Logger)(const char *msg, enum LogLevel lvl);

const char *getloglevel(enum LogLevel lvl) {
  switch (lvl) {
  case DEBUG:
    return "DEBUG";
    break;
  case INFO:
    return "INFO";
    break;
  case WARNING:
    return "WARNING";
    break;
  case ERROR:
    return "ERROR";
    break;
  }
}

void consoleLogger(const char *msg, enum LogLevel lvl) {
  printf("%s: %s\n", getloglevel(lvl), msg);
}

void fileLogger(const char *msg, enum LogLevel lvl) {
  FILE *file = fopen("log.txt", "a");
  if (!file)
    fprintf(stderr, "Couldn't Open File\n");
  fprintf(file, "%s:%s\n", getloglevel(lvl), msg);
  fclose(file);
}

void performTask(Logger logger) {

  logger("Componenet needs checking", DEBUG);
  logger("Invalid Data Initialization", ERROR);
  logger("Connection stable", INFO);
  logger("Implementation could lead to potential overhead", WARNING);
}

void formatted_output(const char *msg, enum LogLevel lvl) {
  time_t timer;
  struct tm* tm_info;
  time(&timer);
  tm_info=localtime(&timer);
  char res[20];
  strftime(res,sizeof(res),"%Y:%m:%d  %H:%M:%S",tm_info);

  const char* reset_color="\033[0m";
  const char* color;

  switch(lvl){
    case DEBUG:   color = "\033[36m"; break; // Cyan
        case INFO:    color = "\033[32m"; break;  // Green
        case WARNING: color = "\033[33m"; break;// Yellow
        case ERROR:   color = "\033[31m"; break; // Red
  }

  printf("%s[%s] [%s] %s%s\n",color,res,getloglevel(lvl),msg,reset_color);
}


int main()
{
  srand(time(NULL));
  performTask(consoleLogger);
  performTask(fileLogger);
  performTask(formatted_output);

  return 0; 
}