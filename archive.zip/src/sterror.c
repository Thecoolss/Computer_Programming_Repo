#include<stdio.h>
#include<stdlib.h>
#include<string.h>

enum ErrorCode{
  MACESS,
  MNOMEM,
  MINVAL,
};


char * getErrorMessage(enum ErrorCode erc){
  switch(erc){
    case MACESS:
    return "Permission Denied";
    break;
    case MNOMEM:
    return "Out of Memory";
    break;
    case MINVAL:
    return "Invalid Argument";
    break;
  }
}



int main()
{

  enum ErrorCode e=MINVAL;
  printf("Error Message: %s\n",getErrorMessage(e));
  e=MACESS;
  printf("Error Message: %s\n",getErrorMessage(e));
  e=MNOMEM;
  printf("Error Message: %s\n",getErrorMessage(e));
  return 0;
}